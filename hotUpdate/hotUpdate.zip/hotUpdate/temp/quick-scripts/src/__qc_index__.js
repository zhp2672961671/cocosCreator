
require('./assets/Script/Helloworld');
require('./assets/Script/hotupdate');
require('./assets/migration/use_v2.1-2.2.1_cc.Toggle_event');
