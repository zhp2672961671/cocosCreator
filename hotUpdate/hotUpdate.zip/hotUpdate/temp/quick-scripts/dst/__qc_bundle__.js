
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Helloworld');
require('./assets/Script/hotupdate');
require('./assets/migration/use_v2.1-2.2.1_cc.Toggle_event');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/hotupdate.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '92cf70DxStB5YOXYCT9fNH0', 'hotupdate');
// Script/hotupdate.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**显示更新信息 */
        _this.label = null;
        /**当前版本信息 */
        _this.versionStr = null;
        /**远程版本资源缓存路径 */
        _this.storagePath = "";
        /**资源管理 */
        _this.am = null;
        /**更新状态 */
        _this.updating = false;
        /**版本资源信息文件 */
        _this.mainifestUrl = null;
        /**远程版本 */
        _this.remoteVersion = "";
        /**热更后的搜索路径 */
        _this.HotUpdateSearchPaths = "HotUpdateSearchPaths";
        /**远程资源缓存路径 */
        _this.remotePath = "remotePath";
        _this.curVersion = "curVersion";
        return _this;
    }
    Helloworld.prototype.start = function () {
    };
    Helloworld.prototype.onLoad = function () {
        this.versionStr.string = this.getCurVesion();
        this.storagePath = this.getRootPath();
        cc.log('远程版本缓存路径 : ' + this.storagePath);
        this.am = new jsb.AssetsManager('', this.storagePath, this.versionCompareHanle);
        this.am.setVerifyCallback(this.setVerifycb.bind(this));
    };
    Helloworld.prototype.setVerifycb = function (path, asset) {
        var compressed = asset.compressed;
        var expectedMD5 = asset.md5;
        var relativePath = asset.path;
        var size = asset.size;
        cc.log("assetPath", path);
        cc.log("assetSize:", size);
        if (compressed) {
            this.label.string = "检查压缩 : " + relativePath;
            return true;
        }
        else {
            this.label.string = "检查压缩 : " + relativePath + ' (' + expectedMD5 + ')';
            return true;
        }
    };
    /**比较版本 版本不同则更新*/
    Helloworld.prototype.versionCompareHanle = function (versionA, versionB) {
        console.log("\u5F53\u524D\u7248\u672C :  " + versionA + " , \u8FDC\u7A0B\u7248\u672C : " + versionB);
        var vA = versionA.split('.');
        var vB = versionB.split('.');
        for (var i = 0; i < vA.length && i < vB.length; ++i) {
            var a = parseInt(vA[i]);
            var b = parseInt(vB[i]);
            if (a === b) {
                continue;
            }
            else {
                return -1;
            }
        }
        if (vB.length > vA.length) {
            return -1;
        }
        return 0;
    };
    Helloworld.prototype.checkUpdate = function () {
        if (this.updating) {
            return;
        }
        var url = this.mainifestUrl.nativeUrl;
        cc.log("原包版本信息url:", this.mainifestUrl.nativeUrl);
        if (this.am.getState() === jsb.AssetsManager.State.UNINITED) {
            if (cc.loader.md5Pipe) {
                url = cc.loader.md5Pipe.transformURL(url);
            }
            this.am.loadLocalManifest(url);
        }
        if (!this.am.getLocalManifest() || !this.am.getLocalManifest().isLoaded()) {
            this.label.string = '加载本地manifest文件失败';
            return;
        }
        this.am.setEventCallback(this.checkCb.bind(this));
        this.am.checkUpdate();
        this.updating = true;
    };
    Helloworld.prototype.checkCb = function (event) {
        cc.log('Code: ' + event.getEventCode());
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.label.string = "没有本地manifest文件，跳过热更.";
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.label.string = "下载远程manifest文件失败，跳过热更.";
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                this.label.string = "已经更新到远程最新版本.";
                break;
            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                this.label.string = '发现新版本，请尝试热更';
                break;
            default:
                return;
        }
        this.am.setEventCallback(null);
        this.updating = false;
    };
    Helloworld.prototype.hotUpdate = function () {
        if (this.am && !this.updating) {
            this.am.setEventCallback(this.updateCb.bind(this));
            if (this.am.getState() === jsb.AssetsManager.State.UNINITED) {
                var url = this.mainifestUrl.nativeUrl;
                if (cc.loader.md5Pipe) {
                    url = cc.loader.md5Pipe.transformURL(url);
                }
                this.am.loadLocalManifest(url);
            }
            this.am.update();
            this.updating = true;
        }
    };
    Helloworld.prototype.updateCb = function (event) {
        cc.log("热更回调");
        var needRestart = false;
        var failed = false;
        var mm = event.getMessage();
        if (mm) {
            this.label.string = 'Updated file: ' + mm;
        }
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.label.string = '没有本地manifest文件，跳过热更.';
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                console.log("当前下载文件数", event.getDownloadedFiles());
                console.log("总文件数", event.getTotalFiles());
                var msg = event.getMessage();
                if (msg) {
                    this.label.string = '更新的文件：: ' + msg;
                }
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.label.string = '下载远程manifest文件失败，跳过热更.';
                failed = true;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                this.label.string = '已经更新到远程最新版本.';
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED:
                this.label.string = '更新完成，即将重启游戏. ' + event.getMessage();
                needRestart = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FAILED:
                this.label.string = '更新失败. ' + event.getMessage();
                this.updating = false;
                // this._canRetry = true;
                break;
            case jsb.EventAssetsManager.ERROR_UPDATING:
                this.label.string = 'Asset 更新错误: ' + event.getAssetId() + ', ' + event.getMessage();
                break;
            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                this.label.string = event.getMessage();
                break;
            default:
                break;
        }
        if (failed) {
            this.updating = false;
        }
        /**重启游戏，并把缓存资源路径前置到搜索路径 */
        if (needRestart) {
            this.remoteVersion = this.getRemoteVersion();
            cc.log("remoteversion:", this.remoteVersion);
            this.am.setEventCallback(null);
            var searchPaths = jsb.fileUtils.getSearchPaths();
            var newPaths = this.am.getLocalManifest().getSearchPaths();
            Array.prototype.unshift(searchPaths, newPaths);
            cc.sys.localStorage.setItem(this.HotUpdateSearchPaths, JSON.stringify(searchPaths));
            jsb.fileUtils.setSearchPaths(searchPaths);
            cc.sys.localStorage.setItem(this.curVersion, this.remoteVersion);
            cc.game.restart();
        }
    };
    Helloworld.prototype.getRemoteVersion = function () {
        var storagePath = this.getRootPath();
        console.log("有下载的manifest文件", storagePath);
        var loadManifest = jsb.fileUtils.getStringFromFile(storagePath + '/project.manifest');
        var manifestObject = JSON.parse(loadManifest);
        return manifestObject.version;
    };
    /**获取缓存路径 */
    Helloworld.prototype.getRootPath = function () {
        return ((jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + this.remotePath);
    };
    /**
     * 获取版本号
     * 如果已存有版本号则直接返回，如果没有则在本地manifest文件中取版本号；
     */
    Helloworld.prototype.getCurVesion = function () {
        var curversion = cc.sys.localStorage.getItem(this.curVersion);
        cc.log("curversion", curversion);
        if (curversion)
            return curversion;
        var storagePath = this.getRootPath();
        storagePath = this.mainifestUrl.nativeUrl;
        if (storagePath) {
            var loadManifest = jsb.fileUtils.getStringFromFile(storagePath);
            var manifestObject = JSON.parse(loadManifest);
            curversion = manifestObject.version;
            console.log("当前版本号origin：", curversion);
        }
        return curversion;
    };
    /**获取远程动态 url和版本号 ，版本号相同，直接进入游戏，否则重新设置project.manifest地址数据 然后更新 */
    Helloworld.prototype.configUpdate = function () {
        cc.sys.localStorage.removeItem("curVersion");
        var curVersion = this.getCurVesion();
        var remoteVersion = "1.1.0";
        // 大版本号
        // curVersion第一个数字为主版本号，如果大版本大于本地版本则重新下载包（大版本更新部分）
        var curMainId = 1;
        var bigVersion = 1;
        if (bigVersion > curMainId) {
            var rootpath = this.getRootPath();
            //删掉之前大版本的缓存路径
            jsb.fileUtils.removeDirectory(rootpath);
            //清除缓存的版本号 和 版本路径  
            cc.sys.localStorage.removeItem("curversion");
            var packageUrl = "apk/api地址";
            cc.sys.openURL(packageUrl);
            return;
        }
        //下面是 资源的更新检查（小版本更新部分）
        var needcheck = this.versionCompareHanle(curVersion, remoteVersion);
        // 本地版本和远程版本 相同直接跳转登陆, 这里 加判断是为了 防止每次都下载 manifest文件
        if (needcheck == 0) {
            console.log("小版本相同 进入登陆界面");
            return;
        }
        //拼接远程资源的下载地址
        var scripturl = "远程服务器地址";
        this._modifyAppLoadUrlForManifestFile(scripturl, this.mainifestUrl.nativeUrl);
    };
    /**
    * 修改.manifest文件,如果有缓存则比较缓存的版本和应用包的版本，取较高者 热更，如果没有缓存则下载远程的版本文件 取版本号，这里统一修改地址为
    * 远程地址，不管 如何变化 都是从最新的地址下载版本文件。这里远程
    * @param {新的升级包地址} newAppHotUpdateUrl
    * @param {本地project.manifest文件地址} localManifestPath
    */
    Helloworld.prototype._modifyAppLoadUrlForManifestFile = function (newAppHotUpdateUrl, localManifestPath) {
        var isWritten = false;
        if (jsb.fileUtils.isFileExist(jsb.fileUtils.getWritablePath() + 'plane/project.manifest')) {
            var storagePath = this.getRootPath();
            console.log("有下载的manifest文件", storagePath);
            var loadManifest = jsb.fileUtils.getStringFromFile(storagePath + '/project.manifest');
            var manifestObject = JSON.parse(loadManifest);
            manifestObject.packageUrl = newAppHotUpdateUrl;
            manifestObject.remoteManifestUrl = manifestObject.packageUrl + "project.manifest";
            manifestObject.remoteVersionUrl = manifestObject.packageUrl + "version.manifest";
            var afterString = JSON.stringify(manifestObject);
            isWritten = jsb.fileUtils.writeStringToFile(afterString, storagePath + '/project.manifest');
        }
        else {
            /**
             * 执行到这里说明App之前没有进行过热更，所以不存在热更的plane文件夹。
             */
            /**
             * plane文件夹不存在的时候，我们就主动创建“plane”文件夹，并将打包时候的project.manifest文件中升级包地址修改后，存放到“plane”文件夹下面。
             */
            var initializedManifestPath = this.getRootPath();
            if (!jsb.fileUtils.isDirectoryExist(initializedManifestPath)) {
                jsb.fileUtils.createDirectory(initializedManifestPath);
            }
            //修改原始manifest文件
            var originManifestPath = localManifestPath;
            var originManifest = jsb.fileUtils.getStringFromFile(originManifestPath);
            var originManifestObject = JSON.parse(originManifest);
            originManifestObject.packageUrl = newAppHotUpdateUrl;
            originManifestObject.remoteManifestUrl = originManifestObject.packageUrl + 'project.manifest';
            originManifestObject.remoteVersionUrl = originManifestObject.packageUrl + 'version.manifest';
            var afterString = JSON.stringify(originManifestObject);
            isWritten = jsb.fileUtils.writeStringToFile(afterString, initializedManifestPath + '/project.manifest');
        }
        cc.log("Written Status : ", isWritten);
        if (isWritten) {
            this.checkUpdate();
        }
    };
    __decorate([
        property(cc.RichText)
    ], Helloworld.prototype, "label", void 0);
    __decorate([
        property(cc.RichText)
    ], Helloworld.prototype, "versionStr", void 0);
    __decorate([
        property(cc.Asset)
    ], Helloworld.prototype, "mainifestUrl", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHQvaG90dXBkYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBdVRDO1FBdFRHLFlBQVk7UUFFWixXQUFLLEdBQWdCLElBQUksQ0FBQztRQUMxQixZQUFZO1FBRVosZ0JBQVUsR0FBZ0IsSUFBSSxDQUFDO1FBQy9CLGdCQUFnQjtRQUNoQixpQkFBVyxHQUFVLEVBQUUsQ0FBQztRQUN4QixVQUFVO1FBQ1YsUUFBRSxHQUFxQixJQUFJLENBQUM7UUFDNUIsVUFBVTtRQUNWLGNBQVEsR0FBVyxLQUFLLENBQUM7UUFDekIsY0FBYztRQUVkLGtCQUFZLEdBQVksSUFBSSxDQUFDO1FBQzdCLFVBQVU7UUFDRixtQkFBYSxHQUFVLEVBQUUsQ0FBQztRQUNsQyxjQUFjO1FBQ04sMEJBQW9CLEdBQVUsc0JBQXNCLENBQUM7UUFDN0QsY0FBYztRQUNOLGdCQUFVLEdBQVUsWUFBWSxDQUFDO1FBQ2pDLGdCQUFVLEdBQVUsWUFBWSxDQUFDOztJQWlTN0MsQ0FBQztJQWhTRywwQkFBSyxHQUFMO0lBQ0EsQ0FBQztJQUNELDJCQUFNLEdBQU47UUFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDN0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdEMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ2hGLElBQUksQ0FBQyxFQUFFLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBRUQsZ0NBQVcsR0FBWCxVQUFZLElBQUksRUFBQyxLQUFLO1FBQ2xCLElBQUksVUFBVSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUM7UUFDbEMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQztRQUM1QixJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQzlCLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDdEIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUMsSUFBSSxDQUFDLENBQUE7UUFDeEIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUIsSUFBSSxVQUFVLEVBQUU7WUFDWixJQUFJLENBQUUsS0FBSyxDQUFDLE1BQU0sR0FBRyxTQUFTLEdBQUcsWUFBWSxDQUFDO1lBQzlDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7YUFDSTtZQUNELElBQUksQ0FBRSxLQUFLLENBQUMsTUFBTSxHQUFHLFNBQVMsR0FBRyxZQUFZLEdBQUcsSUFBSSxHQUFHLFdBQVcsR0FBRyxHQUFHLENBQUM7WUFDekUsT0FBTyxJQUFJLENBQUM7U0FDZjtJQUNMLENBQUM7SUFDRCxpQkFBaUI7SUFDakIsd0NBQW1CLEdBQW5CLFVBQXFCLFFBQWlCLEVBQUcsUUFBaUI7UUFDdEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBVyxRQUFRLHNDQUFhLFFBQVUsQ0FBQyxDQUFDO1FBQ3hELElBQUksRUFBRSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDN0IsSUFBSSxFQUFFLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sRUFBRyxFQUFFLENBQUMsRUFBRTtZQUNuRCxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEIsSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3hCLElBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDVixTQUFTO2FBQ1o7aUJBQ0c7Z0JBQ0EsT0FBUSxDQUFDLENBQUMsQ0FBQzthQUNkO1NBQ0o7UUFDRCxJQUFLLEVBQUUsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU0sRUFBQztZQUN2QixPQUFPLENBQUMsQ0FBQyxDQUFDO1NBQ2I7UUFDRCxPQUFPLENBQUMsQ0FBQztJQUNiLENBQUM7SUFJRCxnQ0FBVyxHQUFYO1FBQ0ksSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2YsT0FBTztTQUNWO1FBQ0QsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUM7UUFDdEMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQTtRQUNoRCxJQUFJLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLEtBQUssR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFO1lBQ3pELElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ25CLEdBQUcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDN0M7WUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xDO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUN2RSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQztZQUN2QyxPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztJQUN6QixDQUFDO0lBRUQsNEJBQU8sR0FBUCxVQUFRLEtBQUs7UUFDVCxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztRQUN4QyxRQUFRLEtBQUssQ0FBQyxZQUFZLEVBQUUsRUFBRTtZQUMxQixLQUFLLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyx1QkFBdUI7Z0JBQy9DLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLHNCQUFzQixDQUFDO2dCQUMzQyxNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsdUJBQXVCLENBQUM7WUFDcEQsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsb0JBQW9CO2dCQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyx3QkFBd0IsQ0FBQztnQkFDN0MsTUFBTTtZQUNWLEtBQUssR0FBRyxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQjtnQkFDMUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsY0FBYyxDQUFDO2dCQUNuQyxNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCO2dCQUN6QyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUM7Z0JBQ2xDLE1BQU07WUFDVjtnQkFDSSxPQUFPO1NBQ2Q7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFFRCw4QkFBUyxHQUFUO1FBQ0ksSUFBSSxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUMzQixJQUFJLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDbkQsSUFBSSxJQUFJLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxLQUFLLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRTtnQkFDekQsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUM7Z0JBQ3RDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7b0JBQ25CLEdBQUcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQzdDO2dCQUNELElBQUksQ0FBQyxFQUFFLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDbEM7WUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1NBQ3hCO0lBQ0wsQ0FBQztJQUVELDZCQUFRLEdBQVIsVUFBUyxLQUFLO1FBQ1YsRUFBRSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUNkLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztRQUN4QixJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQzVCLElBQUksRUFBRSxFQUFFO1lBQ0osSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO1NBQzdDO1FBQ0QsUUFBUSxLQUFLLENBQUMsWUFBWSxFQUFFLEVBQUU7WUFFMUIsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsdUJBQXVCO2dCQUMvQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxzQkFBc0IsQ0FBQztnQkFDM0MsTUFBTSxHQUFHLElBQUksQ0FBQztnQkFDZCxNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCO2dCQUMxQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBQyxLQUFLLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFBO2dCQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQTtnQkFDekMsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUM3QixJQUFJLEdBQUcsRUFBRTtvQkFDTCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDO2lCQUN4QztnQkFDRCxNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsdUJBQXVCLENBQUM7WUFDcEQsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsb0JBQW9CO2dCQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyx3QkFBd0IsQ0FBQztnQkFDN0MsTUFBTSxHQUFHLElBQUksQ0FBQztnQkFDZCxNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCO2dCQUMxQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxjQUFjLENBQUM7Z0JBQ25DLE1BQU0sR0FBRyxJQUFJLENBQUM7Z0JBQ2QsTUFBTTtZQUNWLEtBQUssR0FBRyxDQUFDLGtCQUFrQixDQUFDLGVBQWU7Z0JBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLGVBQWUsR0FBRyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ3pELFdBQVcsR0FBRyxJQUFJLENBQUM7Z0JBQ25CLE1BQU07WUFDVixLQUFLLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhO2dCQUNyQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxRQUFRLEdBQUcsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNsRCxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztnQkFDdEIseUJBQXlCO2dCQUN6QixNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsY0FBYztnQkFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsY0FBYyxHQUFHLEtBQUssQ0FBQyxVQUFVLEVBQUUsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNwRixNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCO2dCQUN4QyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ3ZDLE1BQU07WUFDVjtnQkFDSSxNQUFNO1NBQ2I7UUFHRCxJQUFJLE1BQU0sRUFBRTtZQUNSLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1NBQ3pCO1FBQ0QsMEJBQTBCO1FBQzFCLElBQUksV0FBVyxFQUFFO1lBQ2IsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUM3QyxFQUFFLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQTtZQUMzQyxJQUFJLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQy9CLElBQUksV0FBVyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDakQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQzNELEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUMvQyxFQUFFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUNwRixHQUFHLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMxQyxFQUFFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7WUFDL0QsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUNyQjtJQUNMLENBQUM7SUFFRCxxQ0FBZ0IsR0FBaEI7UUFDSSxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBQyxXQUFXLENBQUMsQ0FBQztRQUMxQyxJQUFJLFlBQVksR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsR0FBRyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3RGLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDOUMsT0FBTyxjQUFjLENBQUMsT0FBTyxDQUFDO0lBQ2xDLENBQUM7SUFFRCxZQUFZO0lBQ1osZ0NBQVcsR0FBWDtRQUNJLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2RixDQUFDO0lBQ0Q7OztPQUdHO0lBQ0gsaUNBQVksR0FBWjtRQUNJLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDOUQsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUMsVUFBVSxDQUFDLENBQUE7UUFDL0IsSUFBRyxVQUFVO1lBQUUsT0FBTyxVQUFVLENBQUE7UUFDaEMsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3JDLFdBQVcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQztRQUMxQyxJQUFJLFdBQVcsRUFBRTtZQUNiLElBQUksWUFBWSxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDaEUsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM5QyxVQUFVLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQztZQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBQyxVQUFVLENBQUMsQ0FBQTtTQUN6QztRQUNELE9BQU8sVUFBVSxDQUFDO0lBQ3JCLENBQUM7SUFHRixrRUFBa0U7SUFDbEUsaUNBQVksR0FBWjtRQUVJLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQTtRQUM1QyxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDckMsSUFBSSxhQUFhLEdBQUksT0FBTyxDQUFBO1FBQ3pCLE9BQU87UUFDUCxrREFBa0Q7UUFDakQsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFBO1FBQ2pCLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQTtRQUNsQixJQUFHLFVBQVUsR0FBRyxTQUFTLEVBQUM7WUFDdEIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2xDLGNBQWM7WUFDZCxHQUFHLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxtQkFBbUI7WUFDbkIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQzlDLElBQUssVUFBVSxHQUFHLFdBQVcsQ0FBQztZQUM3QixFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMzQixPQUFPO1NBQ1Y7UUFDRCxzQkFBc0I7UUFDdkIsSUFBSSxTQUFTLEdBQUksSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsRUFBQyxhQUFhLENBQUMsQ0FBQztRQUNwRSxtREFBbUQ7UUFDbEQsSUFBRyxTQUFTLElBQUksQ0FBQyxFQUFDO1lBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQTtZQUMzQixPQUFRO1NBQ1g7UUFDRCxhQUFhO1FBQ2IsSUFBSSxTQUFTLEdBQUksU0FBUyxDQUFBO1FBQzFCLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0RixDQUFDO0lBQ0E7Ozs7O01BS0U7SUFDSCxxREFBZ0MsR0FBaEMsVUFBaUMsa0JBQWtCLEVBQUUsaUJBQWlCO1FBQzlELElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLEdBQUcsd0JBQXdCLENBQUMsRUFBRTtZQUN2RixJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBQyxXQUFXLENBQUMsQ0FBQztZQUMxQyxJQUFJLFlBQVksR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsR0FBRyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3RGLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDOUMsY0FBYyxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQztZQUMvQyxjQUFjLENBQUMsaUJBQWlCLEdBQUcsY0FBYyxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQztZQUNsRixjQUFjLENBQUMsZ0JBQWdCLEdBQUcsY0FBYyxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQztZQUNqRixJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ2pELFNBQVMsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxXQUFXLEdBQUcsbUJBQW1CLENBQUMsQ0FBQztTQUMvRjthQUFNO1lBQ0g7O2VBRUc7WUFFSDs7ZUFFRztZQUNILElBQUksdUJBQXVCLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2pELElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLHVCQUF1QixDQUFDLEVBQUU7Z0JBQzFELEdBQUcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLHVCQUF1QixDQUFDLENBQUM7YUFDMUQ7WUFDRCxnQkFBZ0I7WUFDaEIsSUFBSSxrQkFBa0IsR0FBRyxpQkFBaUIsQ0FBQztZQUMzQyxJQUFJLGNBQWMsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDekUsSUFBSSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3RELG9CQUFvQixDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQztZQUNyRCxvQkFBb0IsQ0FBQyxpQkFBaUIsR0FBRyxvQkFBb0IsQ0FBQyxVQUFVLEdBQUcsa0JBQWtCLENBQUM7WUFDOUYsb0JBQW9CLENBQUMsZ0JBQWdCLEdBQUcsb0JBQW9CLENBQUMsVUFBVSxHQUFHLGtCQUFrQixDQUFDO1lBRTdGLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUN2RCxTQUFTLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsdUJBQXVCLEdBQUcsbUJBQW1CLENBQUMsQ0FBQztTQUMzRztRQUNELEVBQUUsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdkMsSUFBRyxTQUFTLEVBQUM7WUFDVCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDdEI7SUFFVCxDQUFDO0lBbFREO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUM7NkNBQ0k7SUFHMUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQztrREFDUztJQVMvQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO29EQUNVO0lBZlosVUFBVTtRQUQ5QixPQUFPO09BQ2EsVUFBVSxDQXVUOUI7SUFBRCxpQkFBQztDQXZURCxBQXVUQyxDQXZUdUMsRUFBRSxDQUFDLFNBQVMsR0F1VG5EO2tCQXZUb0IsVUFBVSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSGVsbG93b3JsZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XG4gICAgLyoq5pi+56S65pu05paw5L+h5oGvICovXG4gICAgQHByb3BlcnR5KGNjLlJpY2hUZXh0KVxuICAgIGxhYmVsOiBjYy5SaWNoVGV4dCA9IG51bGw7XG4gICAgLyoq5b2T5YmN54mI5pys5L+h5oGvICovXG4gICAgQHByb3BlcnR5KGNjLlJpY2hUZXh0KVxuICAgIHZlcnNpb25TdHI6IGNjLlJpY2hUZXh0ID0gbnVsbDtcbiAgICAvKirov5znqIvniYjmnKzotYTmupDnvJPlrZjot6/lvoQgKi9cbiAgICBzdG9yYWdlUGF0aDpzdHJpbmcgPSBcIlwiO1xuICAgIC8qKui1hOa6kOeuoeeQhiAqL1xuICAgIGFtOmpzYi5Bc3NldHNNYW5hZ2VyID0gbnVsbDtcbiAgICAvKirmm7TmlrDnirbmgIEgKi9cbiAgICB1cGRhdGluZzpib29sZWFuID0gZmFsc2U7XG4gICAgLyoq54mI5pys6LWE5rqQ5L+h5oGv5paH5Lu2ICovXG4gICAgQHByb3BlcnR5KGNjLkFzc2V0KVxuICAgIG1haW5pZmVzdFVybDpjYy5Bc3NldCA9IG51bGw7XG4gICAgLyoq6L+c56iL54mI5pysICovXG4gICAgcHJpdmF0ZSByZW1vdGVWZXJzaW9uOnN0cmluZyA9IFwiXCI7XG4gICAgLyoq54Ot5pu05ZCO55qE5pCc57Si6Lev5b6EICovXG4gICAgcHJpdmF0ZSBIb3RVcGRhdGVTZWFyY2hQYXRoczpzdHJpbmcgPSBcIkhvdFVwZGF0ZVNlYXJjaFBhdGhzXCI7XG4gICAgLyoq6L+c56iL6LWE5rqQ57yT5a2Y6Lev5b6EICovXG4gICAgcHJpdmF0ZSByZW1vdGVQYXRoOnN0cmluZyA9IFwicmVtb3RlUGF0aFwiO1xuICAgIHByaXZhdGUgY3VyVmVyc2lvbjpzdHJpbmcgPSBcImN1clZlcnNpb25cIjtcbiAgICBzdGFydCAoKSB7XG4gICAgfVxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy52ZXJzaW9uU3RyLnN0cmluZyA9IHRoaXMuZ2V0Q3VyVmVzaW9uKCk7XG4gICAgICAgIHRoaXMuc3RvcmFnZVBhdGggPSB0aGlzLmdldFJvb3RQYXRoKCk7XG4gICAgICAgIGNjLmxvZygn6L+c56iL54mI5pys57yT5a2Y6Lev5b6EIDogJyArIHRoaXMuc3RvcmFnZVBhdGgpO1xuICAgICAgICB0aGlzLmFtID0gbmV3IGpzYi5Bc3NldHNNYW5hZ2VyKCcnLCB0aGlzLnN0b3JhZ2VQYXRoLCB0aGlzLnZlcnNpb25Db21wYXJlSGFubGUpO1xuICAgICAgICB0aGlzLmFtLnNldFZlcmlmeUNhbGxiYWNrKHRoaXMuc2V0VmVyaWZ5Y2IuYmluZCh0aGlzKSk7XG4gICAgfVxuXG4gICAgc2V0VmVyaWZ5Y2IocGF0aCxhc3NldCl7XG4gICAgICAgIGxldCBjb21wcmVzc2VkID0gYXNzZXQuY29tcHJlc3NlZDtcbiAgICAgICAgbGV0IGV4cGVjdGVkTUQ1ID0gYXNzZXQubWQ1O1xuICAgICAgICBsZXQgcmVsYXRpdmVQYXRoID0gYXNzZXQucGF0aDtcbiAgICAgICAgbGV0IHNpemUgPSBhc3NldC5zaXplO1xuICAgICAgICBjYy5sb2coXCJhc3NldFBhdGhcIixwYXRoKVxuICAgICAgICBjYy5sb2coXCJhc3NldFNpemU6XCIsc2l6ZSk7XG4gICAgICAgIGlmIChjb21wcmVzc2VkKSB7XG4gICAgICAgICAgICB0aGlzIC5sYWJlbC5zdHJpbmcgPSBcIuajgOafpeWOi+e8qSA6IFwiICsgcmVsYXRpdmVQYXRoO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzIC5sYWJlbC5zdHJpbmcgPSBcIuajgOafpeWOi+e8qSA6IFwiICsgcmVsYXRpdmVQYXRoICsgJyAoJyArIGV4cGVjdGVkTUQ1ICsgJyknO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoq5q+U6L6D54mI5pysIOeJiOacrOS4jeWQjOWImeabtOaWsCovXG4gICAgdmVyc2lvbkNvbXBhcmVIYW5sZSggdmVyc2lvbkEgOiBzdHJpbmcgLCB2ZXJzaW9uQiA6IHN0cmluZyApe1xuwqAgwqAgwqAgwqAgY29uc29sZS5sb2coYOW9k+WJjeeJiOacrCA6ICAke3ZlcnNpb25BfSAsIOi/nOeoi+eJiOacrCA6ICR7dmVyc2lvbkJ9YCk7XG7CoCDCoCDCoCDCoCBsZXQgdkEgPSB2ZXJzaW9uQS5zcGxpdCgnLicpO1xuwqAgwqAgwqAgwqAgbGV0IHZCID0gdmVyc2lvbkIuc3BsaXQoJy4nKTtcbsKgIMKgIMKgIMKgIGZvciggbGV0IGkgPSAwIDsgaSA8IHZBLmxlbmd0aCAmJiBpIDwgdkIubGVuZ3RoIDsgKytpICl7XG7CoCDCoCDCoCDCoCDCoCDCoCBsZXQgYSA9IHBhcnNlSW50KHZBW2ldKTtcbsKgIMKgIMKgIMKgIMKgIMKgIGxldCBiID0gcGFyc2VJbnQodkJbaV0pO1xuwqAgwqAgwqAgwqAgwqAgwqAgaWYgKCBhID09PSBiICl7XG7CoCDCoCDCoCDCoCDCoCDCoCDCoCDCoCBjb250aW51ZTtcbsKgIMKgIMKgIMKgIMKgIMKgIH1cbsKgIMKgIMKgIMKgIMKgIMKgIGVsc2V7XG7CoCDCoCDCoCDCoCDCoCDCoCDCoCDCoCByZXR1cm4gIC0xO1xuwqAgwqAgwqAgwqAgwqAgwqAgfVxuwqAgwqAgwqAgwqAgfVxuwqAgwqAgwqAgwqAgaWYgKCB2Qi5sZW5ndGggPiB2QS5sZW5ndGgpe1xuwqAgwqAgwqAgwqAgwqAgwqAgcmV0dXJuIC0xO1xuwqAgwqAgwqAgwqAgfVxuwqAgwqAgwqAgwqAgcmV0dXJuIDA7XG4gICAgfVxuXG4gICBcblxuICAgIGNoZWNrVXBkYXRlKCkge1xuICAgICAgICBpZiAodGhpcy51cGRhdGluZykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGxldCB1cmwgPSB0aGlzLm1haW5pZmVzdFVybC5uYXRpdmVVcmw7XG4gICAgICAgIGNjLmxvZyhcIuWOn+WMheeJiOacrOS/oeaBr3VybDpcIix0aGlzLm1haW5pZmVzdFVybC5uYXRpdmVVcmwpXG4gICAgICAgIGlmICh0aGlzLmFtLmdldFN0YXRlKCkgPT09IGpzYi5Bc3NldHNNYW5hZ2VyLlN0YXRlLlVOSU5JVEVEKSB7XG4gICAgICAgICAgICBpZiAoY2MubG9hZGVyLm1kNVBpcGUpIHtcbiAgICAgICAgICAgICAgICB1cmwgPSBjYy5sb2FkZXIubWQ1UGlwZS50cmFuc2Zvcm1VUkwodXJsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuYW0ubG9hZExvY2FsTWFuaWZlc3QodXJsKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuYW0uZ2V0TG9jYWxNYW5pZmVzdCgpIHx8ICF0aGlzLmFtLmdldExvY2FsTWFuaWZlc3QoKS5pc0xvYWRlZCgpKSB7XG4gICAgICAgICAgICB0aGlzLmxhYmVsLnN0cmluZyA9ICfliqDovb3mnKzlnLBtYW5pZmVzdOaWh+S7tuWksei0pSc7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5hbS5zZXRFdmVudENhbGxiYWNrKHRoaXMuY2hlY2tDYi5iaW5kKHRoaXMpKTtcbsKgIMKgIMKgIMKgIHRoaXMuYW0uY2hlY2tVcGRhdGUoKTtcbiAgICAgICAgdGhpcy51cGRhdGluZyA9IHRydWU7XG4gICAgfVxuXG4gICAgY2hlY2tDYihldmVudCkge1xuICAgICAgICBjYy5sb2coJ0NvZGU6ICcgKyBldmVudC5nZXRFdmVudENvZGUoKSk7XG4gICAgICAgIHN3aXRjaCAoZXZlbnQuZ2V0RXZlbnRDb2RlKCkpIHtcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9OT19MT0NBTF9NQU5JRkVTVDpcbiAgICAgICAgICAgICAgICB0aGlzLmxhYmVsLnN0cmluZyA9IFwi5rKh5pyJ5pys5ZywbWFuaWZlc3Tmlofku7bvvIzot7Pov4fng63mm7QuXCI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfRE9XTkxPQURfTUFOSUZFU1Q6XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfUEFSU0VfTUFOSUZFU1Q6XG4gICAgICAgICAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSBcIuS4i+i9vei/nOeoi21hbmlmZXN05paH5Lu25aSx6LSl77yM6Lez6L+H54Ot5pu0LlwiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkFMUkVBRFlfVVBfVE9fREFURTpcbiAgICAgICAgICAgICAgICB0aGlzLmxhYmVsLnN0cmluZyA9IFwi5bey57uP5pu05paw5Yiw6L+c56iL5pyA5paw54mI5pysLlwiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLk5FV19WRVJTSU9OX0ZPVU5EOlxuICAgICAgICAgICAgICAgIHRoaXMubGFiZWwuc3RyaW5nID0gJ+WPkeeOsOaWsOeJiOacrO+8jOivt+WwneivleeDreabtCc7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFtLnNldEV2ZW50Q2FsbGJhY2sobnVsbCk7XG4gICAgICAgIHRoaXMudXBkYXRpbmcgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBob3RVcGRhdGUoKSB7XG4gICAgICAgIGlmICh0aGlzLmFtICYmICF0aGlzLnVwZGF0aW5nKSB7XG4gICAgICAgICAgICB0aGlzLmFtLnNldEV2ZW50Q2FsbGJhY2sodGhpcy51cGRhdGVDYi5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIGlmICh0aGlzLmFtLmdldFN0YXRlKCkgPT09IGpzYi5Bc3NldHNNYW5hZ2VyLlN0YXRlLlVOSU5JVEVEKSB7XG4gICAgICAgICAgICAgICAgbGV0IHVybCA9IHRoaXMubWFpbmlmZXN0VXJsLm5hdGl2ZVVybDtcbiAgICAgICAgICAgICAgICBpZiAoY2MubG9hZGVyLm1kNVBpcGUpIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsID0gY2MubG9hZGVyLm1kNVBpcGUudHJhbnNmb3JtVVJMKHVybCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuYW0ubG9hZExvY2FsTWFuaWZlc3QodXJsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuYW0udXBkYXRlKCk7XG4gICAgICAgICAgICB0aGlzLnVwZGF0aW5nID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHVwZGF0ZUNiKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZyhcIueDreabtOWbnuiwg1wiKVxuICAgICAgICB2YXIgbmVlZFJlc3RhcnQgPSBmYWxzZTtcbiAgICAgICAgdmFyIGZhaWxlZCA9IGZhbHNlO1xuICAgICAgICBsZXQgbW0gPSBldmVudC5nZXRNZXNzYWdlKCk7XG4gICAgICAgIGlmIChtbSkge1xuICAgICAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSAnVXBkYXRlZCBmaWxlOiAnICsgbW07XG4gICAgICAgIH1cbiAgICAgICAgc3dpdGNoIChldmVudC5nZXRFdmVudENvZGUoKSkge1xuICAgICAgICAgICBcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9OT19MT0NBTF9NQU5JRkVTVDpcbiAgICAgICAgICAgICAgICB0aGlzLmxhYmVsLnN0cmluZyA9ICfmsqHmnInmnKzlnLBtYW5pZmVzdOaWh+S7tu+8jOi3s+i/h+eDreabtC4nO1xuICAgICAgICAgICAgICAgIGZhaWxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuVVBEQVRFX1BST0dSRVNTSU9OOlxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2T5YmN5LiL6L295paH5Lu25pWwXCIsZXZlbnQuZ2V0RG93bmxvYWRlZEZpbGVzKCkpXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLmgLvmlofku7bmlbBcIixldmVudC5nZXRUb3RhbEZpbGVzKCkpXG4gICAgICAgICAgICAgICAgdmFyIG1zZyA9IGV2ZW50LmdldE1lc3NhZ2UoKTtcbiAgICAgICAgICAgICAgICBpZiAobXNnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGFiZWwuc3RyaW5nID0gJ+abtOaWsOeahOaWh+S7tu+8mjogJyArIG1zZztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfRE9XTkxPQURfTUFOSUZFU1Q6XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfUEFSU0VfTUFOSUZFU1Q6XG4gICAgICAgICAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSAn5LiL6L296L+c56iLbWFuaWZlc3Tmlofku7blpLHotKXvvIzot7Pov4fng63mm7QuJztcbiAgICAgICAgICAgICAgICBmYWlsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkFMUkVBRFlfVVBfVE9fREFURTpcbiAgICAgICAgICAgICAgICB0aGlzLmxhYmVsLnN0cmluZyA9ICflt7Lnu4/mm7TmlrDliLDov5znqIvmnIDmlrDniYjmnKwuJztcbiAgICAgICAgICAgICAgICBmYWlsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLlVQREFURV9GSU5JU0hFRDpcbiAgICAgICAgICAgICAgICB0aGlzLmxhYmVsLnN0cmluZyA9ICfmm7TmlrDlrozmiJDvvIzljbPlsIbph43lkK/muLjmiI8uICcgKyBldmVudC5nZXRNZXNzYWdlKCk7XG4gICAgICAgICAgICAgICAgbmVlZFJlc3RhcnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLlVQREFURV9GQUlMRUQ6XG4gICAgICAgICAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSAn5pu05paw5aSx6LSlLiAnICsgZXZlbnQuZ2V0TWVzc2FnZSgpO1xuICAgICAgICAgICAgICAgIHRoaXMudXBkYXRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl9jYW5SZXRyeSA9IHRydWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfVVBEQVRJTkc6XG4gICAgICAgICAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSAnQXNzZXQg5pu05paw6ZSZ6K+vOiAnICsgZXZlbnQuZ2V0QXNzZXRJZCgpICsgJywgJyArIGV2ZW50LmdldE1lc3NhZ2UoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9ERUNPTVBSRVNTOlxuICAgICAgICAgICAgICAgIHRoaXMubGFiZWwuc3RyaW5nID0gZXZlbnQuZ2V0TWVzc2FnZSgpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBcblxuICAgICAgICBpZiAoZmFpbGVkKSB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0aW5nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgLyoq6YeN5ZCv5ri45oiP77yM5bm25oqK57yT5a2Y6LWE5rqQ6Lev5b6E5YmN572u5Yiw5pCc57Si6Lev5b6EICovXG4gICAgICAgIGlmIChuZWVkUmVzdGFydCkge1xuICAgICAgICAgICAgdGhpcy5yZW1vdGVWZXJzaW9uID0gdGhpcy5nZXRSZW1vdGVWZXJzaW9uKCk7XG4gICAgICAgICAgICBjYy5sb2coXCJyZW1vdGV2ZXJzaW9uOlwiLHRoaXMucmVtb3RlVmVyc2lvbilcbiAgICAgICAgICAgIHRoaXMuYW0uc2V0RXZlbnRDYWxsYmFjayhudWxsKTtcbiAgICAgICAgICAgIGxldCBzZWFyY2hQYXRocyA9IGpzYi5maWxlVXRpbHMuZ2V0U2VhcmNoUGF0aHMoKTtcbiAgICAgICAgICAgIGxldCBuZXdQYXRocyA9IHRoaXMuYW0uZ2V0TG9jYWxNYW5pZmVzdCgpLmdldFNlYXJjaFBhdGhzKCk7XG4gICAgICAgICAgICBBcnJheS5wcm90b3R5cGUudW5zaGlmdChzZWFyY2hQYXRocywgbmV3UGF0aHMpO1xuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKHRoaXMuSG90VXBkYXRlU2VhcmNoUGF0aHMsIEpTT04uc3RyaW5naWZ5KHNlYXJjaFBhdGhzKSk7XG4gICAgICAgICAgICBqc2IuZmlsZVV0aWxzLnNldFNlYXJjaFBhdGhzKHNlYXJjaFBhdGhzKTtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLmN1clZlcnNpb24sdGhpcy5yZW1vdGVWZXJzaW9uKVxuICAgICAgICAgICAgY2MuZ2FtZS5yZXN0YXJ0KCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBnZXRSZW1vdGVWZXJzaW9uKCl7XG4gICAgICAgIGxldCBzdG9yYWdlUGF0aCA9IHRoaXMuZ2V0Um9vdFBhdGgoKTtcbiAgICAgICAgY29uc29sZS5sb2coXCLmnInkuIvovb3nmoRtYW5pZmVzdOaWh+S7tlwiLHN0b3JhZ2VQYXRoKTtcbiAgICAgICAgbGV0IGxvYWRNYW5pZmVzdCA9IGpzYi5maWxlVXRpbHMuZ2V0U3RyaW5nRnJvbUZpbGUoc3RvcmFnZVBhdGggKyAnL3Byb2plY3QubWFuaWZlc3QnKTtcbiAgICAgICAgbGV0IG1hbmlmZXN0T2JqZWN0ID0gSlNPTi5wYXJzZShsb2FkTWFuaWZlc3QpO1xuICAgICAgICByZXR1cm4gbWFuaWZlc3RPYmplY3QudmVyc2lvbjtcbiAgICB9XG5cbiAgICAvKirojrflj5bnvJPlrZjot6/lvoQgKi9cbiAgICBnZXRSb290UGF0aCgpe1xuICAgICAgICByZXR1cm4gKChqc2IuZmlsZVV0aWxzID8ganNiLmZpbGVVdGlscy5nZXRXcml0YWJsZVBhdGgoKSA6ICcvJykgKyB0aGlzLnJlbW90ZVBhdGgpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiDojrflj5bniYjmnKzlj7dcbiAgICAgKiDlpoLmnpzlt7LlrZjmnInniYjmnKzlj7fliJnnm7TmjqXov5Tlm57vvIzlpoLmnpzmsqHmnInliJnlnKjmnKzlnLBtYW5pZmVzdOaWh+S7tuS4reWPlueJiOacrOWPt++8m1xuICAgICAqL1xuICAgIGdldEN1clZlc2lvbigpe1xuICAgICAgICBsZXQgY3VydmVyc2lvbiA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLmN1clZlcnNpb24pO1xuICAgICAgICBjYy5sb2coXCJjdXJ2ZXJzaW9uXCIsY3VydmVyc2lvbilcbiAgICAgICAgaWYoY3VydmVyc2lvbikgcmV0dXJuIGN1cnZlcnNpb25cbiAgICAgICAgbGV0IHN0b3JhZ2VQYXRoID0gdGhpcy5nZXRSb290UGF0aCgpO1xuICAgICAgICBzdG9yYWdlUGF0aCA9IHRoaXMubWFpbmlmZXN0VXJsLm5hdGl2ZVVybDtcbiAgICAgICAgaWYgKHN0b3JhZ2VQYXRoICl7XG4gICAgICAgICAgICBsZXQgbG9hZE1hbmlmZXN0ID0ganNiLmZpbGVVdGlscy5nZXRTdHJpbmdGcm9tRmlsZShzdG9yYWdlUGF0aCk7XG4gICAgICAgICAgICBsZXQgbWFuaWZlc3RPYmplY3QgPSBKU09OLnBhcnNlKGxvYWRNYW5pZmVzdCk7XG4gICAgICAgICAgICBjdXJ2ZXJzaW9uID0gbWFuaWZlc3RPYmplY3QudmVyc2lvbjtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2T5YmN54mI5pys5Y+3b3JpZ2lu77yaXCIsY3VydmVyc2lvbilcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY3VydmVyc2lvbjtcbiAgICAgfVxuXG5cbiAgICAvKirojrflj5bov5znqIvliqjmgIEgdXJs5ZKM54mI5pys5Y+3IO+8jOeJiOacrOWPt+ebuOWQjO+8jOebtOaOpei/m+WFpea4uOaIj++8jOWQpuWImemHjeaWsOiuvue9rnByb2plY3QubWFuaWZlc3TlnLDlnYDmlbDmja4g54S25ZCO5pu05pawICovXG4gICAgY29uZmlnVXBkYXRlKClcbiAgICB7ICAgXG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcImN1clZlcnNpb25cIilcbiAgICAgICAgbGV0IGN1clZlcnNpb24gPSB0aGlzLmdldEN1clZlc2lvbigpO1xuICAgICAgICBsZXQgcmVtb3RlVmVyc2lvbiAgPSBcIjEuMS4wXCJcbiAgICAgICAgICAgLy8g5aSn54mI5pys5Y+3XG4gICAgICAgICAgIC8vIGN1clZlcnNpb27nrKzkuIDkuKrmlbDlrZfkuLrkuLvniYjmnKzlj7fvvIzlpoLmnpzlpKfniYjmnKzlpKfkuo7mnKzlnLDniYjmnKzliJnph43mlrDkuIvovb3ljIXvvIjlpKfniYjmnKzmm7TmlrDpg6jliIbvvIlcbiAgICAgICAgICAgIGxldCBjdXJNYWluSWQgPSAxXG4gICAgICAgICAgICBsZXQgYmlnVmVyc2lvbiA9IDFcbiAgICAgICAgICAgIGlmKGJpZ1ZlcnNpb24gPiBjdXJNYWluSWQpe1xuICAgICAgICAgICAgICAgIGxldCByb290cGF0aCA9IHRoaXMuZ2V0Um9vdFBhdGgoKTtcbiAgICAgICAgICAgICAgICAvL+WIoOaOieS5i+WJjeWkp+eJiOacrOeahOe8k+WtmOi3r+W+hFxuICAgICAgICAgICAgICAgIGpzYi5maWxlVXRpbHMucmVtb3ZlRGlyZWN0b3J5KHJvb3RwYXRoKTtcbiAgICAgICAgICAgICAgICAvL+a4hemZpOe8k+WtmOeahOeJiOacrOWPtyDlkowg54mI5pys6Lev5b6EICBcbiAgICAgICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJjdXJ2ZXJzaW9uXCIpO1xuICAgICAgICAgICAgICAgbGV0ICBwYWNrYWdlVXJsID0gXCJhcGsvYXBp5Zyw5Z2AXCI7XG4gICAgICAgICAgICAgICAgY2Muc3lzLm9wZW5VUkwocGFja2FnZVVybCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy/kuIvpnaLmmK8g6LWE5rqQ55qE5pu05paw5qOA5p+l77yI5bCP54mI5pys5pu05paw6YOo5YiG77yJXG4gICAgICAgICAgIGxldCBuZWVkY2hlY2sgPSAgdGhpcy52ZXJzaW9uQ29tcGFyZUhhbmxlKGN1clZlcnNpb24scmVtb3RlVmVyc2lvbik7XG4gICAgICAgICAgIC8vIOacrOWcsOeJiOacrOWSjOi/nOeoi+eJiOacrCDnm7jlkIznm7TmjqXot7PovaznmbvpmYYsIOi/memHjCDliqDliKTmlq3mmK/kuLrkuoYg6Ziy5q2i5q+P5qyh6YO95LiL6L29IG1hbmlmZXN05paH5Lu2XG4gICAgICAgICAgICBpZihuZWVkY2hlY2sgPT0gMCl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLlsI/niYjmnKznm7jlkIwg6L+b5YWl55m76ZmG55WM6Z2iXCIpXG4gICAgICAgICAgICAgICAgcmV0dXJuIDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8v5ou85o6l6L+c56iL6LWE5rqQ55qE5LiL6L295Zyw5Z2AXG4gICAgICAgICAgICBsZXQgc2NyaXB0dXJsID0gIFwi6L+c56iL5pyN5Yqh5Zmo5Zyw5Z2AXCJcbiAgICAgICAgICAgIHRoaXMuX21vZGlmeUFwcExvYWRVcmxGb3JNYW5pZmVzdEZpbGUoc2NyaXB0dXJsLCB0aGlzLm1haW5pZmVzdFVybC5uYXRpdmVVcmwpOyBcbiAgICB9XG4gICAgIC8qKlxuICAgICAqIOS/ruaUuS5tYW5pZmVzdOaWh+S7tizlpoLmnpzmnInnvJPlrZjliJnmr5TovoPnvJPlrZjnmoTniYjmnKzlkozlupTnlKjljIXnmoTniYjmnKzvvIzlj5bovoPpq5jogIUg54Ot5pu077yM5aaC5p6c5rKh5pyJ57yT5a2Y5YiZ5LiL6L296L+c56iL55qE54mI5pys5paH5Lu2IOWPlueJiOacrOWPt++8jOi/memHjOe7n+S4gOS/ruaUueWcsOWdgOS4ulxuICAgICAqIOi/nOeoi+WcsOWdgO+8jOS4jeeuoSDlpoLkvZXlj5jljJYg6YO95piv5LuO5pyA5paw55qE5Zyw5Z2A5LiL6L2954mI5pys5paH5Lu244CC6L+Z6YeM6L+c56iLXG4gICAgICogQHBhcmFtIHvmlrDnmoTljYfnuqfljIXlnLDlnYB9IG5ld0FwcEhvdFVwZGF0ZVVybCBcbiAgICAgKiBAcGFyYW0ge+acrOWcsHByb2plY3QubWFuaWZlc3Tmlofku7blnLDlnYB9IGxvY2FsTWFuaWZlc3RQYXRoIFxuICAgICAqL1xuICAgIF9tb2RpZnlBcHBMb2FkVXJsRm9yTWFuaWZlc3RGaWxlKG5ld0FwcEhvdFVwZGF0ZVVybCwgbG9jYWxNYW5pZmVzdFBhdGgpIHtcbiAgICAgICAgICAgIGxldCBpc1dyaXR0ZW4gPSBmYWxzZTtcbiAgICAgICAgICAgIGlmIChqc2IuZmlsZVV0aWxzLmlzRmlsZUV4aXN0KGpzYi5maWxlVXRpbHMuZ2V0V3JpdGFibGVQYXRoKCkgKyAncGxhbmUvcHJvamVjdC5tYW5pZmVzdCcpKSB7XG4gICAgICAgICAgICAgICAgbGV0IHN0b3JhZ2VQYXRoID0gdGhpcy5nZXRSb290UGF0aCgpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5pyJ5LiL6L2955qEbWFuaWZlc3Tmlofku7ZcIixzdG9yYWdlUGF0aCk7XG4gICAgICAgICAgICAgICAgbGV0IGxvYWRNYW5pZmVzdCA9IGpzYi5maWxlVXRpbHMuZ2V0U3RyaW5nRnJvbUZpbGUoc3RvcmFnZVBhdGggKyAnL3Byb2plY3QubWFuaWZlc3QnKTtcbiAgICAgICAgICAgICAgICBsZXQgbWFuaWZlc3RPYmplY3QgPSBKU09OLnBhcnNlKGxvYWRNYW5pZmVzdCk7XG4gICAgICAgICAgICAgICAgbWFuaWZlc3RPYmplY3QucGFja2FnZVVybCA9IG5ld0FwcEhvdFVwZGF0ZVVybDtcbiAgICAgICAgICAgICAgICBtYW5pZmVzdE9iamVjdC5yZW1vdGVNYW5pZmVzdFVybCA9IG1hbmlmZXN0T2JqZWN0LnBhY2thZ2VVcmwgKyBcInByb2plY3QubWFuaWZlc3RcIjtcbiAgICAgICAgICAgICAgICBtYW5pZmVzdE9iamVjdC5yZW1vdGVWZXJzaW9uVXJsID0gbWFuaWZlc3RPYmplY3QucGFja2FnZVVybCArIFwidmVyc2lvbi5tYW5pZmVzdFwiO1xuICAgICAgICAgICAgICAgIGxldCBhZnRlclN0cmluZyA9IEpTT04uc3RyaW5naWZ5KG1hbmlmZXN0T2JqZWN0KTtcbiAgICAgICAgICAgICAgICBpc1dyaXR0ZW4gPSBqc2IuZmlsZVV0aWxzLndyaXRlU3RyaW5nVG9GaWxlKGFmdGVyU3RyaW5nLCBzdG9yYWdlUGF0aCArICcvcHJvamVjdC5tYW5pZmVzdCcpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiDmiafooYzliLDov5nph4zor7TmmI5BcHDkuYvliY3msqHmnInov5vooYzov4fng63mm7TvvIzmiYDku6XkuI3lrZjlnKjng63mm7TnmoRwbGFuZeaWh+S7tuWkueOAglxuICAgICAgICAgICAgICAgICAqL1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogcGxhbmXmlofku7blpLnkuI3lrZjlnKjnmoTml7blgJnvvIzmiJHku6zlsLHkuLvliqjliJvlu7rigJxwbGFuZeKAneaWh+S7tuWkue+8jOW5tuWwhuaJk+WMheaXtuWAmeeahHByb2plY3QubWFuaWZlc3Tmlofku7bkuK3ljYfnuqfljIXlnLDlnYDkv67mlLnlkI7vvIzlrZjmlL7liLDigJxwbGFuZeKAneaWh+S7tuWkueS4i+mdouOAglxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIGxldCBpbml0aWFsaXplZE1hbmlmZXN0UGF0aCA9IHRoaXMuZ2V0Um9vdFBhdGgoKTtcbiAgICAgICAgICAgICAgICBpZiAoIWpzYi5maWxlVXRpbHMuaXNEaXJlY3RvcnlFeGlzdChpbml0aWFsaXplZE1hbmlmZXN0UGF0aCkpIHtcbiAgICAgICAgICAgICAgICAgICAganNiLmZpbGVVdGlscy5jcmVhdGVEaXJlY3RvcnkoaW5pdGlhbGl6ZWRNYW5pZmVzdFBhdGgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvL+S/ruaUueWOn+Wni21hbmlmZXN05paH5Lu2XG4gICAgICAgICAgICAgICAgbGV0IG9yaWdpbk1hbmlmZXN0UGF0aCA9IGxvY2FsTWFuaWZlc3RQYXRoO1xuICAgICAgICAgICAgICAgIGxldCBvcmlnaW5NYW5pZmVzdCA9IGpzYi5maWxlVXRpbHMuZ2V0U3RyaW5nRnJvbUZpbGUob3JpZ2luTWFuaWZlc3RQYXRoKTtcbiAgICAgICAgICAgICAgICBsZXQgb3JpZ2luTWFuaWZlc3RPYmplY3QgPSBKU09OLnBhcnNlKG9yaWdpbk1hbmlmZXN0KTtcbiAgICAgICAgICAgICAgICBvcmlnaW5NYW5pZmVzdE9iamVjdC5wYWNrYWdlVXJsID0gbmV3QXBwSG90VXBkYXRlVXJsO1xuICAgICAgICAgICAgICAgIG9yaWdpbk1hbmlmZXN0T2JqZWN0LnJlbW90ZU1hbmlmZXN0VXJsID0gb3JpZ2luTWFuaWZlc3RPYmplY3QucGFja2FnZVVybCArICdwcm9qZWN0Lm1hbmlmZXN0JztcbiAgICAgICAgICAgICAgICBvcmlnaW5NYW5pZmVzdE9iamVjdC5yZW1vdGVWZXJzaW9uVXJsID0gb3JpZ2luTWFuaWZlc3RPYmplY3QucGFja2FnZVVybCArICd2ZXJzaW9uLm1hbmlmZXN0JztcblxuICAgICAgICAgICAgICAgIGxldCBhZnRlclN0cmluZyA9IEpTT04uc3RyaW5naWZ5KG9yaWdpbk1hbmlmZXN0T2JqZWN0KTtcbiAgICAgICAgICAgICAgICBpc1dyaXR0ZW4gPSBqc2IuZmlsZVV0aWxzLndyaXRlU3RyaW5nVG9GaWxlKGFmdGVyU3RyaW5nLCBpbml0aWFsaXplZE1hbmlmZXN0UGF0aCArICcvcHJvamVjdC5tYW5pZmVzdCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2MubG9nKFwiV3JpdHRlbiBTdGF0dXMgOiBcIiwgaXNXcml0dGVuKTtcbiAgICAgICAgICAgIGlmKGlzV3JpdHRlbil7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja1VwZGF0ZSgpO1xuICAgICAgICAgICAgfVxuXG4gICAgfVxuXG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/migration/use_v2.1-2.2.1_cc.Toggle_event.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd51b9WsYBFLjZlAM2UBfHra', 'use_v2.1-2.2.1_cc.Toggle_event');
// migration/use_v2.1-2.2.1_cc.Toggle_event.js

"use strict";

/*
 * This script is automatically generated by Cocos Creator and is only used for projects compatible with the v2.1.0 ～ 2.2.1 version.
 * You do not need to manually add this script in any other project.
 * If you don't use cc.Toggle in your project, you can delete this script directly.
 * If your project is hosted in VCS such as git, submit this script together.
 *
 * 此脚本由 Cocos Creator 自动生成，仅用于兼容 v2.1.0 ~ 2.2.1 版本的工程，
 * 你无需在任何其它项目中手动添加此脚本。
 * 如果你的项目中没用到 Toggle，可直接删除该脚本。
 * 如果你的项目有托管于 git 等版本库，请将此脚本一并上传。
 */
if (cc.Toggle) {
  // Whether to trigger 'toggle' and 'checkEvents' events when modifying 'toggle.isChecked' in the code
  // 在代码中修改 'toggle.isChecked' 时是否触发 'toggle' 与 'checkEvents' 事件
  cc.Toggle._triggerEventInScript_isChecked = true;
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9taWdyYXRpb24vdXNlX3YyLjEtMi4yLjFfY2MuVG9nZ2xlX2V2ZW50LmpzIl0sIm5hbWVzIjpbImNjIiwiVG9nZ2xlIiwiX3RyaWdnZXJFdmVudEluU2NyaXB0X2lzQ2hlY2tlZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7QUFZQSxJQUFJQSxFQUFFLENBQUNDLE1BQVAsRUFBZTtBQUNYO0FBQ0E7QUFDQUQsRUFBQUEsRUFBRSxDQUFDQyxNQUFILENBQVVDLCtCQUFWLEdBQTRDLElBQTVDO0FBQ0giLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBUaGlzIHNjcmlwdCBpcyBhdXRvbWF0aWNhbGx5IGdlbmVyYXRlZCBieSBDb2NvcyBDcmVhdG9yIGFuZCBpcyBvbmx5IHVzZWQgZm9yIHByb2plY3RzIGNvbXBhdGlibGUgd2l0aCB0aGUgdjIuMS4wIO+9niAyLjIuMSB2ZXJzaW9uLlxuICogWW91IGRvIG5vdCBuZWVkIHRvIG1hbnVhbGx5IGFkZCB0aGlzIHNjcmlwdCBpbiBhbnkgb3RoZXIgcHJvamVjdC5cbiAqIElmIHlvdSBkb24ndCB1c2UgY2MuVG9nZ2xlIGluIHlvdXIgcHJvamVjdCwgeW91IGNhbiBkZWxldGUgdGhpcyBzY3JpcHQgZGlyZWN0bHkuXG4gKiBJZiB5b3VyIHByb2plY3QgaXMgaG9zdGVkIGluIFZDUyBzdWNoIGFzIGdpdCwgc3VibWl0IHRoaXMgc2NyaXB0IHRvZ2V0aGVyLlxuICpcbiAqIOatpOiEmuacrOeUsSBDb2NvcyBDcmVhdG9yIOiHquWKqOeUn+aIkO+8jOS7heeUqOS6juWFvOWuuSB2Mi4xLjAgfiAyLjIuMSDniYjmnKznmoTlt6XnqIvvvIxcbiAqIOS9oOaXoOmcgOWcqOS7u+S9leWFtuWug+mhueebruS4reaJi+WKqOa3u+WKoOatpOiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5Lit5rKh55So5YiwIFRvZ2dsZe+8jOWPr+ebtOaOpeWIoOmZpOivpeiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5pyJ5omY566h5LqOIGdpdCDnrYnniYjmnKzlupPvvIzor7flsIbmraTohJrmnKzkuIDlubbkuIrkvKDjgIJcbiAqL1xuXG5pZiAoY2MuVG9nZ2xlKSB7XG4gICAgLy8gV2hldGhlciB0byB0cmlnZ2VyICd0b2dnbGUnIGFuZCAnY2hlY2tFdmVudHMnIGV2ZW50cyB3aGVuIG1vZGlmeWluZyAndG9nZ2xlLmlzQ2hlY2tlZCcgaW4gdGhlIGNvZGVcbiAgICAvLyDlnKjku6PnoIHkuK3kv67mlLkgJ3RvZ2dsZS5pc0NoZWNrZWQnIOaXtuaYr+WQpuinpuWPkSAndG9nZ2xlJyDkuI4gJ2NoZWNrRXZlbnRzJyDkuovku7ZcbiAgICBjYy5Ub2dnbGUuX3RyaWdnZXJFdmVudEluU2NyaXB0X2lzQ2hlY2tlZCA9IHRydWU7XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Helloworld.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld');
// Script/Helloworld.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.text = 'hello';
        return _this;
    }
    Helloworld.prototype.start = function () {
        // init logic
        this.label.string = this.text;
    };
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "label", void 0);
    __decorate([
        property
    ], Helloworld.prototype, "text", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9TY3JpcHQvSGVsbG93b3JsZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUF3Qyw4QkFBWTtJQUFwRDtRQUFBLHFFQVlDO1FBVEcsV0FBSyxHQUFhLElBQUksQ0FBQztRQUd2QixVQUFJLEdBQVcsT0FBTyxDQUFDOztJQU0zQixDQUFDO0lBSkcsMEJBQUssR0FBTDtRQUNJLGFBQWE7UUFDYixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2xDLENBQUM7SUFSRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOzZDQUNJO0lBR3ZCO1FBREMsUUFBUTs0Q0FDYztJQU5OLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0FZOUI7SUFBRCxpQkFBQztDQVpELEFBWUMsQ0FadUMsRUFBRSxDQUFDLFNBQVMsR0FZbkQ7a0JBWm9CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEhlbGxvd29ybGQgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gICAgQHByb3BlcnR5KGNjLkxhYmVsKVxuICAgIGxhYmVsOiBjYy5MYWJlbCA9IG51bGw7XG5cbiAgICBAcHJvcGVydHlcbiAgICB0ZXh0OiBzdHJpbmcgPSAnaGVsbG8nO1xuXG4gICAgc3RhcnQgKCkge1xuICAgICAgICAvLyBpbml0IGxvZ2ljXG4gICAgICAgIHRoaXMubGFiZWwuc3RyaW5nID0gdGhpcy50ZXh0O1xuICAgIH1cbn1cbiJdfQ==
//------QC-SOURCE-SPLIT------
